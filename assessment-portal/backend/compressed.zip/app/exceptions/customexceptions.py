class UserAlreadyExistsException(Exception):
    """Raised when the email already exists."""
    pass


class UsernameAlreadyExistsException(Exception):
    """Raised when the username already exists."""
    pass


class UserNotFoundException(Exception):
    """Raised when the user is not found."""
    pass


class InvalidPasswordException(Exception):
    """Raised when password is incorrect."""
    pass


class AdminAlreadyExistsException(Exception):
    """Raised when an admin already exists."""
    pass


class InvalidTokenException(Exception):
    """Raised when JWT token is invalid or expired."""
    pass


class UnauthorizedException(Exception):
    """Raised when user is unauthorized."""
    pass


class ForbiddenException(Exception):
    """Raised when user does not have permission."""
    pass